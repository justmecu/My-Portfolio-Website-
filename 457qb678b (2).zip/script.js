function showTime() {
	const currentTime = document.getElementById('currentTime');
	if (!currentTime) return;

	currentTime.textContent = new Date().toUTCString();
}

if (document.getElementById('currentTime')) {
	showTime();
	setInterval(showTime, 1000);
}